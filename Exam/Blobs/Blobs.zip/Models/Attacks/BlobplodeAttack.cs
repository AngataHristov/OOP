﻿
namespace Blobs.Models.Attacks
{
    using Enumerations;

    public class BlobplodeAttack : Attack
    {
        public BlobplodeAttack(int damage, AttackTypes types)
            : base(damage, types)
        {
        }
    }
}
