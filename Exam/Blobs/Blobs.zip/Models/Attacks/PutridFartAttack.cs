﻿
namespace Blobs.Models.Attacks
{
    using Enumerations;

    public class PutridFartAttack : Attack
    {
        public PutridFartAttack(int damage, AttackTypes types)
            : base(damage, types)
        {
        }
    }
}
