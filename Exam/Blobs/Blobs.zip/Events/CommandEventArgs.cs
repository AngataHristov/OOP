﻿
namespace Blobs.Events
{
    using System;

    public class CommandEventArgs : EventArgs
    {
        public bool Stopped;
    }
}
