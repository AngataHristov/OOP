﻿
namespace Blobs.Core.Commands
{
    using Interfaces;

    public class PassCommand : CommandAbstract
    {
        public PassCommand()
            : base(null)
        {

        }

        public override void Execute()
        {

        }
    }
}
