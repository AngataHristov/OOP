﻿
namespace Blobs.Enumerations
{
    public enum BehaviorTypes
    {
        Aggressive,
        Inflated
    }
}
