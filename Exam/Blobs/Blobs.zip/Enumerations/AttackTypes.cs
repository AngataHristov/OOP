﻿
namespace Blobs.Enumerations
{
    public enum AttackTypes
    {
        PutridFart,
        Blobplode
    }
}
